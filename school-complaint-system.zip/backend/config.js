// backend/config.js
module.exports = {
    port: 5000,
    mongoURI: 'mongodb://localhost:27017/school-complaint-system',
    jwtSecret: 'school_complaint_system',
  };
  
  
// src/components/HomePage.js
import React from 'react';

const HomePage = ({ token }) => {
  return (
    <div>
      <h1>Welcome to the School Complaint System</h1>
      <p>Use this system to submit and track complaints.</p>
    </div>
  );
};

export default HomePage;

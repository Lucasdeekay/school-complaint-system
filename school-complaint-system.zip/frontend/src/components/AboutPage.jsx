// src/components/AboutPage.js
import React from 'react';

const AboutPage = ({ token }) => {
  return (
    <div>
      <h1>Learn More About School Complaint System</h1>
      <p>Use this system to submit and track complaints.</p>
    </div>
  );
};

export default AboutPage;
